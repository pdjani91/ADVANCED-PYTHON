from datetime import datetime
ct = datetime.now()					# Calling Method using class name
print("Current Date and Time:", ct)
print("Date:", ct.day)
print("Month:", ct.month)
print("Year:", ct.year)
print("Hour:", ct.hour)
print("Minute:", ct.minute)
print("Second:", ct.second)
print("Microsecond:", ct.microsecond)
print()

ct1 = datetime.today()				# Calling Method using class name
print("Current Date and Time:", ct1)
print("Date:", ct1.day)
print("Month:", ct1.month)
print("Year:", ct1.year)
print("Hour:", ct1.hour)
print("Minute:", ct1.minute)
print("Second:", ct1.second)
print("Microsecond:", ct1.microsecond)
print()
