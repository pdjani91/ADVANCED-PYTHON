# Writing Data with x mode
f = open('student4.txt', mode='x')
f.write('Hello\n')
f.write('GeekyShows\n')
f.write('How are you')
f.close()
print('Success')

