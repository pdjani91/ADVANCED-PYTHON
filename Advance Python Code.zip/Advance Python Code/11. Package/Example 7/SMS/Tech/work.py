# Tech Package --> work Module
from User.request import user_request
def tech_work():
	print("Tech Package --> work Module")
	print("tech_work Function")
	print()
	user_request()