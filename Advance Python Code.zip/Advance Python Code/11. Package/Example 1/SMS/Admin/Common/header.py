# Admin Package --> Common Package --> header Module

def admin_common_header():
	print("Admin Package --> Common Package --> header Module")
	print("admin_common_header Function")
	print()