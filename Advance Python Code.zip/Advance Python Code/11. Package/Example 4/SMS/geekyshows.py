# geekyshows Module

# Accessing all module from Admin Package
from Admin import *
from Admin.Common import *
service.admin_service()
product.admin_product()
header.admin_common_header()
footer.admin_common_footer()

