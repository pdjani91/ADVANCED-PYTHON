# Admin Package --> Common Package --> __init__ Module
__all__ = ['footer', 'header']