import os
# It will remove all mentioned
os.removedirs('parentdir/childdir/grandchilddir')		



