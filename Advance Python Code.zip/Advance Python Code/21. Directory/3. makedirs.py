import os
os.makedirs('parentdir/childdir/grandchilddir')