a = 10
b = 0
try:
    d = a/b
    print(d)
    
except:
    print('Exception Handler')

print('Rest of the Code')
