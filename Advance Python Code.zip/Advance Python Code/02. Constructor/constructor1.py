# Constructor
class Mobile:
	def __init__(self):
		print("Mobile Constructor Called")


realme = Mobile()

