import threading
t = threading.current_thread().getName()
print(t)