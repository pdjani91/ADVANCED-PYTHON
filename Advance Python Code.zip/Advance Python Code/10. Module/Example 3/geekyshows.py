# geekyshows.py <--- Main Module

import cal as c							# Importing Cal Module

print("cal Module's variable:", c.a)	# Accessing Cal Module's Variable

c.name()								# Accessing Cal Module's Function

a = c.add(10,20)						# Accessing Cal Module's Function
print(a)

b = c.sub(20, 10)						# Accessing Cal Module's Function
print(b)
