#second.py  <--- second Module
class Myclass:
	def disp(self):
		print("Disp Method from Second Module")
	