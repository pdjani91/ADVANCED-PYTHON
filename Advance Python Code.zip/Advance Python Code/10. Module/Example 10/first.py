#first.py  <--- first Module
a = 'First Module'

def name():
	print("Name Function From First Module")
	