# geekyshows.py <--- Main Module

from first import *			# Importing first Module

c = Myclass()		# Creating Myclass Object
c.name()

s = Myschool()		# Creating Myschool Object
s.show()

