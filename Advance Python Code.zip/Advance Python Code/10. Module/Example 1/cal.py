#cal.py  <--- cal Module
a = 50

def name():
	print("From Module cal")
	
def add(a,b):
	return a+b
	
def sub(a,b):
	return a-b